blackjack-1.0
Author: Eric Arnold, aka: beatzz
License: GPLv3.0

Dependencies
In order to run the program, Java SE Runtime Environment 8 or higher must be installed on your system.
- Don't have it? download Java here: 
	https://www.java.com/en/download/ 
- Need help installing Java? Read this document for installation instructions:   
	https://www.java.com/en/download/help/download_options.xml

Execution

- For Windows users, simply extract the blackjack.exe from the archive, and run.
- For Linux users, extract the blackjack.jar file from the archive, and execute with the following commands.
    
      tar -xvjf blackjack-1.0.tar.bz2
      java -jar blackjack-1.0/blackjack.jar

License

- This software is licensed under the GPLv3.0, a copy is in the main archive directory titled LICENCE.
